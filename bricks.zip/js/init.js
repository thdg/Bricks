"use strict";

var g_canvas = document.getElementById("myCanvas");
var g_ctx = g_canvas.getContext("2d");

g_canvas.height = window.innerHeight;
g_canvas.width = window.innerHeight*0.666;

g_ctx.fillStyle = "white";
