"use strict";

/****************************************************************

 EXTRA STUFF:
  1. Multi-hit Bricks
  2. Indestuctable Bricks (just bricks with lives === infinity) C:
  3. levels (and easy to use level creator for developer)
  4. ball trail
  5. particles!!! Super awesome stuff
  6. extra ball
  
*****************************************************************/

// ============
// ENTITIES
// ============

var g_player = new Player({
    score: 0,
    lives: 0
});

var KEY_A = 'A'.charCodeAt(0);
var KEY_D = 'D'.charCodeAt(0);

var g_paddle = new Paddle({
    GO_LEFT  : KEY_A,
    GO_RIGHT : KEY_D,
    
    halfHeight: g_canvas.height/60,
    halfWidth: g_canvas.height/15,
    
    color : "white"
});

var g_balls = [new Ball()];
var g_bricks = getBricks(Math.floor(Math.random()*4));
var g_particles = [];

// =============
// GATHER INPUTS
// =============

function gatherInputs() {
    // Nothing to do here!
    // The event handlers do everything we need for now.
}

// =================
// UPDATE SIMULATION
// =================

// We take a very layered approach here...
//
// The primary `update` routine handles generic stuff such as
// pausing, single-step, and time-handling.
//
// It then delegates the game-specific logic to `updateSimulation`


// GAME-SPECIFIC UPDATE LOGIC

function updateSimulation(du) {
    g_paddle.update(du);
    updateArray(g_balls,du);
    updateArray(g_bricks,du);
    updateArray(g_particles,du);
}

function updateArray(array, du) {
    var i = 0;
    while (array[i]) {
        if (!array[i].dying) {
            array[i++].update(du);
        } else {
            array.splice(i,1); // kill it
        }
    }
}
    


// =================
// RENDER SIMULATION
// =================

// We take a very layered approach here...
//
// The primary `render` routine handles generic stuff such as
// the diagnostic toggles (including screen-clearing).
//
// It then delegates the game-specific logic to `gameRender`


// GAME-SPECIFIC RENDERING

function renderSimulation(ctx) {
    g_paddle.render(ctx);
    renderArray(g_balls,ctx);
    renderArray(g_bricks,ctx);
    renderArray(g_particles,ctx);
}

function renderArray(array, ctx) {
    var i = 0;
    while (array[i]) {
        array[i++].render(ctx);
    }
}

// Kick it off
g_main.init();